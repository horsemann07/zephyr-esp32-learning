/* SPDX-License-Identifier: MIT */
#include "rc_demo_nav.h"
#include <zephyr/kernel.h>
#include <string.h>
#include <stdio.h>

K_MUTEX_DEFINE(nav_lock);
static heltec_nav_screen_t latest;
static int64_t last_update;
static bool have_update;

rc_err_sts_t rc_demo_nav_receive(const char *text)
{
    char direction[12] = {0};
    unsigned meters = 0, speed = 0, gps = 0;
    char extra = 0;
    if (text == NULL || strlen(text) > 85 ||
        sscanf(text, "NAV %11s %u %u %u %c", direction, &meters,
               &speed, &gps, &extra) != 4 ||
        meters > 999 || speed > 240 || gps > 1) {
        return RC_ERR_INVALID_ARG;
    }
    heltec_turn_t turn;
    if (strcmp(direction, "LEFT") == 0) turn = HELTEC_TURN_LEFT;
    else if (strcmp(direction, "RIGHT") == 0) turn = HELTEC_TURN_RIGHT;
    else if (strcmp(direction, "STRAIGHT") == 0) turn = HELTEC_TURN_STRAIGHT;
    else if (strcmp(direction, "ARRIVED") == 0) turn = HELTEC_TURN_ARRIVED;
    else return RC_ERR_INVALID_ARG;

    k_mutex_lock(&nav_lock, K_FOREVER);
    latest.turn = turn;
    latest.distance_m = (uint16_t)meters;
    latest.speed_kmh = (uint16_t)speed;
    latest.gps_valid = gps != 0;
    latest.link = HELTEC_LINK_ONLINE;
    last_update = k_uptime_get();
    have_update = true;
    k_mutex_unlock(&nav_lock);
    return RC_OK;
}

bool rc_demo_nav_latest(heltec_nav_screen_t *out)
{
    if (out == NULL) return false;
    k_mutex_lock(&nav_lock, K_FOREVER);
    bool valid = have_update && k_uptime_get() - last_update < 8000;
    if (valid) *out = latest;
    k_mutex_unlock(&nav_lock);
    return valid;
}

void rc_demo_nav_clear(void)
{
    k_mutex_lock(&nav_lock, K_FOREVER);
    have_update = false;
    k_mutex_unlock(&nav_lock);
}
