/* RideCast development navigation message contract and shared state.
 * ASCII transport only for initial demo. Not the production wire protocol.
 * SPDX-License-Identifier: MIT
 */
#ifndef RC_DEMO_NAV_H_
#define RC_DEMO_NAV_H_
#include <stdbool.h>
#include "heltec_graphic.h"
#include "rc_err_sts.h"

/* Parses: NAV <LEFT|RIGHT|STRAIGHT|ARRIVED> <meters> <kmh> <gps:0|1>
 * Must be called only AFTER successful app authentication.
 */
rc_err_sts_t rc_demo_nav_receive(const char *text);
/* Returns false if no update received in the last 8 seconds. */
bool rc_demo_nav_latest(heltec_nav_screen_t *out);
void rc_demo_nav_clear(void);
#endif
